# SC NET

Original open-source Android network & Wi-Fi diagnostic utility suite (16 features), inspired by network utility workflows without copying proprietary code, branding, or assets.

## Features (1–16)
1. Detailed network overview (IPv4/IPv6, Gateway, DNS, Interface, VPN status).
2. Live Wi-Fi inspection (SSID, BSSID, RSSI dBm + visual bar, Link Speed, Frequency/Band/Channel).
3. Public IP & ASN lookup via external HTTP lookup.
4. Network state transition history log.
5. Local subnet (LAN) reachability scanner.
6. OUI/Vendor prefix lookup (respecting modern Android MAC privacy limits).
7. Trusted vs. New IP device tagging.
8. TCP port scanner for custom host & port lists.
9. Ping diagnostics (min/avg/max RTT and packet loss %).
10. DNS lookup utility with DNS profile selector.
11. Reachability / hop diagnostic probes.
12. Download speed test probe.
13. IP & Subnet CIDR calculator.
14. Wake-on-LAN (WOL) magic packet sender.
15. Report exporter (TXT and JSON) to app internal storage.
16. Dark green/black theme inspired by the custom SC NET launcher icon + saved preferences.

## Build Locally
./gradlew assembleRelease

## Build & Release via GitHub Actions
Upload app-source.zip to the repository root and push a tag starting with v (e.g. v1.0.0) or run the workflow manually from the Actions tab.

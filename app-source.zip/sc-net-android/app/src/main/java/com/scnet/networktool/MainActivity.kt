package com.scnet.networktool

import android.Manifest
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkRequest
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var tvNetInfo: TextView
    private lateinit var tvLanOutput: TextView
    private lateinit var tvDiagOutput: TextView
    private lateinit var tvUtilOutput: TextView
    private lateinit var etTargetHost: EditText
    private lateinit var etPortRange: EditText
    private lateinit var etDiagTarget: EditText
    private lateinit var spDnsServer: Spinner
    private lateinit var etCidr: EditText
    private lateinit var etWolMac: EditText
    private lateinit var etWolIp: EditText

    private val eventHistory = mutableListOf<String>()
    private var latestNetJson: JSONObject = JSONObject()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        refreshNetworkDisplay()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvNetInfo = findViewById(R.id.tvNetInfo)
        tvLanOutput = findViewById(R.id.tvLanOutput)
        tvDiagOutput = findViewById(R.id.tvDiagOutput)
        tvUtilOutput = findViewById(R.id.tvUtilOutput)
        etTargetHost = findViewById(R.id.etTargetHost)
        etPortRange = findViewById(R.id.etPortRange)
        etDiagTarget = findViewById(R.id.etDiagTarget)
        spDnsServer = findViewById(R.id.spDnsServer)
        etCidr = findViewById(R.id.etCidr)
        etWolMac = findViewById(R.id.etWolMac)
        etWolIp = findViewById(R.id.etWolIp)

        val dnsOptions = listOf("System DNS", "Cloudflare (1.1.1.1)", "Google (8.8.8.8)")
        spDnsServer.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, dnsOptions)

        loadSavedPreferences()
        requestRuntimeNetworkPermissions()
        registerNetworkCallback()
        refreshNetworkDisplay()

        findViewById<Button>(R.id.btnRefreshNet).setOnClickListener {
            refreshNetworkDisplay()
        }

        findViewById<Button>(R.id.btnPublicIp).setOnClickListener {
            lifecycleScope.launch {
                tvNetInfo.text = "Querying Public IP & ASN..."
                val res = withContext(Dispatchers.IO) { NetworkEngine.fetchPublicIpInfo() }
                refreshNetworkDisplay()
                tvNetInfo.append("\n\n$res")
            }
        }

        findViewById<Button>(R.id.btnLanScan).setOnClickListener {
            lifecycleScope.launch {
                tvLanOutput.text = "Scanning local subnet..."
                val trusted = getTrustedIps()
                val devices = withContext(Dispatchers.IO) {
                    NetworkEngine.scanLanDevices(trusted)
                }
                tvLanOutput.text = devices.joinToString("\n")
            }
        }

        findViewById<Button>(R.id.btnPortScan).setOnClickListener {
            val host = etTargetHost.text.toString().trim().ifEmpty { "192.168.1.1" }
            val ports = etPortRange.text.toString().trim().ifEmpty { "22,53,80,443" }
            lifecycleScope.launch {
                tvLanOutput.text = "Scanning TCP ports on $host..."
                val result = withContext(Dispatchers.IO) { NetworkEngine.scanPorts(host, ports) }
                tvLanOutput.text = result
            }
        }

        findViewById<Button>(R.id.btnPing).setOnClickListener {
            val host = etDiagTarget.text.toString().trim().ifEmpty { "8.8.8.8" }
            lifecycleScope.launch {
                tvDiagOutput.text = "Pinging $host..."
                val result = withContext(Dispatchers.IO) { NetworkEngine.runPing(host, 4) }
                tvDiagOutput.text = result
            }
        }

        findViewById<Button>(R.id.btnDns).setOnClickListener {
            val domain = etDiagTarget.text.toString().trim().ifEmpty { "example.com" }
            val dnsProfile = spDnsServer.selectedItem?.toString() ?: "System DNS"
            lifecycleScope.launch {
                tvDiagOutput.text = "Resolving DNS for $domain..."
                val result = withContext(Dispatchers.IO) { NetworkEngine.dnsLookup(domain, dnsProfile) }
                tvDiagOutput.text = result
            }
        }

        findViewById<Button>(R.id.btnTraceroute).setOnClickListener {
            val target = etDiagTarget.text.toString().trim().ifEmpty { "1.1.1.1" }
            lifecycleScope.launch {
                tvDiagOutput.text = "Running reachability hops for $target..."
                val result = withContext(Dispatchers.IO) { NetworkEngine.simpleTraceroute(target) }
                tvDiagOutput.text = result
            }
        }

        findViewById<Button>(R.id.btnSpeedTest).setOnClickListener {
            lifecycleScope.launch {
                tvDiagOutput.text = "Running download speed test..."
                val result = withContext(Dispatchers.IO) { NetworkEngine.runSpeedTest() }
                tvDiagOutput.text = result
            }
        }

        findViewById<Button>(R.id.btnSubnet).setOnClickListener {
            val cidr = etCidr.text.toString().trim().ifEmpty { "192.168.1.0/24" }
            val info = NetworkEngine.calculateSubnet(cidr)
            tvUtilOutput.text = if (info == null) {
                "Invalid CIDR format. Use e.g. 192.168.1.0/24"
            } else {
                "[Subnet Calculator] ${info.cidr}\nNetwork: ${info.networkAddress} | Mask: ${info.subnetMask}\nBroadcast: ${info.broadcastAddress}\nUsable Hosts: ${info.usableHosts} (${info.firstHost} - ${info.lastHost})"
            }
        }

        findViewById<Button>(R.id.btnWol).setOnClickListener {
            val mac = etWolMac.text.toString().trim()
            val bcast = etWolIp.text.toString().trim().ifEmpty { "255.255.255.255" }
            lifecycleScope.launch {
                val res = withContext(Dispatchers.IO) { NetworkEngine.sendWakeOnLan(mac, bcast) }
                tvUtilOutput.text = res
            }
        }

        findViewById<Button>(R.id.btnExportTxt).setOnClickListener {
            exportReport(asJson = false)
        }

        findViewById<Button>(R.id.btnExportJson).setOnClickListener {
            exportReport(asJson = true)
        }

        findViewById<Button>(R.id.btnSavePrefs).setOnClickListener {
            savePreferences()
        }
    }

    private fun requestRuntimeNetworkPermissions() {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        }
        perms.add(Manifest.permission.ACCESS_FINE_LOCATION)
        perms.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        permissionLauncher.launch(perms.toTypedArray())
    }

    private fun registerNetworkCallback() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val req = NetworkRequest.Builder().build()
        cm.registerNetworkCallback(req, object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                recordEvent("Network available: $network")
                runOnUiThread { refreshNetworkDisplay() }
            }

            override fun onLost(network: Network) {
                recordEvent("Network lost: $network")
                runOnUiThread { refreshNetworkDisplay() }
            }
        })
    }

    private fun recordEvent(msg: String) {
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        eventHistory.add(0, "[$stamp] $msg")
        if (eventHistory.size > 20) eventHistory.removeLast()
    }

    private fun refreshNetworkDisplay() {
        val (summary, json) = NetworkEngine.inspectCurrentNetwork(this)
        latestNetJson = json
        val histText = if (eventHistory.isEmpty()) "No recent transitions." else eventHistory.joinToString("\n")
        tvNetInfo.text = "$summary\n\n[Network History]\n$histText"
    }

    private fun getTrustedIps(): Set<String> {
        val prefs = getSharedPreferences("scnet_prefs", Context.MODE_PRIVATE)
        val raw = prefs.getString("trusted_ips", "192.168.1.1") ?: ""
        return raw.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
    }

    private fun savePreferences() {
        val prefs = getSharedPreferences("scnet_prefs", Context.MODE_PRIVATE)
        prefs.edit()
            .putString("target_host", etTargetHost.text.toString().trim())
            .putString("port_range", etPortRange.text.toString().trim())
            .putString("diag_target", etDiagTarget.text.toString().trim())
            .putString("cidr", etCidr.text.toString().trim())
            .putString("wol_mac", etWolMac.text.toString().trim())
            .putString("wol_ip", etWolIp.text.toString().trim())
            .apply()
        Toast.makeText(this, "SC NET preferences saved", Toast.LENGTH_SHORT).show()
        tvUtilOutput.text = "Preferences saved locally."
    }

    private fun loadSavedPreferences() {
        val prefs = getSharedPreferences("scnet_prefs", Context.MODE_PRIVATE)
        etTargetHost.setText(prefs.getString("target_host", "192.168.1.1"))
        etPortRange.setText(prefs.getString("port_range", "22,53,80,443"))
        etDiagTarget.setText(prefs.getString("diag_target", "8.8.8.8"))
        etCidr.setText(prefs.getString("cidr", "192.168.1.0/24"))
        etWolMac.setText(prefs.getString("wol_mac", ""))
        etWolIp.setText(prefs.getString("wol_ip", "255.255.255.255"))
    }

    private fun exportReport(asJson: Boolean) {
        val dir = File(filesDir, "reports")
        dir.mkdirs()
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val file = if (asJson) {
            val payload = JSONObject().apply {
                put("app", "SC NET")
                put("timestamp", stamp)
                put("network", latestNetJson)
                put("lanOutput", tvLanOutput.text.toString())
                put("diagOutput", tvDiagOutput.text.toString())
                put("utilOutput", tvUtilOutput.text.toString())
            }
            File(dir, "scnet_report_$stamp.json").apply { writeText(payload.toString(2)) }
        } else {
            val content = "SC NET Diagnostic Report ($stamp)\n==================================\n${tvNetInfo.text}\n\n${tvLanOutput.text}\n\n${tvDiagOutput.text}\n\n${tvUtilOutput.text}"
            File(dir, "scnet_report_$stamp.txt").apply { writeText(content) }
        }
        tvUtilOutput.text = "Exported report to: ${file.absolutePath}"
        Toast.makeText(this, "Report saved: ${file.name}", Toast.LENGTH_LONG).show()
    }
}

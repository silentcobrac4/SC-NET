# Dependencies & Sources

- Android Gradle Plugin (com.android.application): Google / Android Open Source Project.
- Kotlin Android Plugin & Coroutines (org.jetbrains.kotlin): JetBrains (Apache-2.0).
- AndroidX Core, AppCompat, ConstraintLayout & Material Components: Android Open Source Project / Google.
- Launcher Icon: Supplied by user (1000057455.png), adapted across Android mipmap densities.
- Public Network Endpoints Used at Runtime (user-triggered):
  - https://ipinfo.io/json for public IP/ASN lookup.
  - https://speed.cloudflare.com/__down?bytes=2000000 for download speed test.

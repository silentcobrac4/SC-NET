package com.scnet.networktool

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.URL
import java.util.Locale

data class SubnetInfo(
    val cidr: String,
    val networkAddress: String,
    val broadcastAddress: String,
    val subnetMask: String,
    val firstHost: String,
    val lastHost: String,
    val usableHosts: Long
)

object NetworkEngine {

    private val ouiMap = mapOf(
        "00:0C:29" to "VMware",
        "00:50:56" to "VMware",
        "DC:A6:32" to "Raspberry Pi Trading",
        "B8:27:EB" to "Raspberry Pi Foundation",
        "FC:EC:DA" to "Ubiquiti Networks",
        "F4:92:BF" to "Ubiquiti Networks",
        "3C:5A:B4" to "Google",
        "A4:83:E7" to "Apple",
        "F0:18:98" to "Apple",
        "00:1B:63" to "Apple",
        "8C:85:90" to "Apple",
        "50:C7:BF" to "TP-Link Technologies",
        "14:CC:20" to "TP-Link Technologies"
    )

    fun lookupVendor(mac: String?): String {
        if (mac.isNullOrBlank()) return "Unavailable (Android privacy)"
        val clean = mac.uppercase(Locale.US).replace("-", ":")
        val prefix = clean.take(8)
        return ouiMap[prefix] ?: "Unknown OUI ($prefix)"
    }

    fun inspectCurrentNetwork(context: Context): Pair<String, JSONObject> {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNet = cm.activeNetwork
        val caps = cm.getNetworkCapabilities(activeNet)
        val lp: LinkProperties? = cm.getLinkProperties(activeNet)

        val transport = when {
            caps == null -> "Disconnected"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Other"
        }
        val hasVpn = caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true

        val ipv4List = mutableListOf<String>()
        val ipv6List = mutableListOf<String>()
        lp?.linkAddresses?.forEach { la ->
            val addr = la.address.hostAddress ?: return@forEach
            val cleanAddr = addr.substringBefore("%")
            if (cleanAddr.contains(":")) ipv6List.add("$cleanAddr/${la.prefixLength}")
            else ipv4List.add("$cleanAddr/${la.prefixLength}")
        }

        val gateways = lp?.routes
            ?.filter { it.isDefaultRoute }
            ?.mapNotNull { it.gateway?.hostAddress }
            ?.distinct()
            ?: emptyList()

        val dnsServers = lp?.dnsServers?.mapNotNull { it.hostAddress } ?: emptyList()

        var wifiSection = "Wi-Fi: Not active"
        val wifiJson = JSONObject()
        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            val info = wm.connectionInfo
            val ssid = info?.ssid?.removeSurrounding("\"") ?: "Unknown/Permission needed"
            val bssid = info?.bssid ?: "02:00:00:00:00:00"
            val rssi = info?.rssi ?: -127
            val linkSpeed = info?.linkSpeed ?: -1
            val freq = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) info?.frequency ?: -1 else -1
            val band = when {
                freq in 2400..2500 -> "2.4 GHz"
                freq in 4900..5900 -> "5 GHz"
                freq > 5900 -> "6 GHz"
                else -> "Unknown"
            }
            val channel = if (freq > 0) freqToChannel(freq).toString() else "N/A"
            val signalBars = when {
                rssi >= -55 -> "|||| (Excellent)"
                rssi >= -67 -> "|||. (Good)"
                rssi >= -75 -> "||.. (Fair)"
                rssi > -120 -> "|... (Weak)"
                else -> ".... (No Signal)"
            }
            wifiSection = "[Wi-Fi Live]\nSSID: $ssid | BSSID: $bssid\nSignal: $rssi dBm $signalBars\nLink Speed: $linkSpeed Mbps | Freq: $freq MHz ($band, Ch $channel)"

            wifiJson.put("ssid", ssid)
            wifiJson.put("bssid", bssid)
            wifiJson.put("rssiDbm", rssi)
            wifiJson.put("linkSpeedMbps", linkSpeed)
            wifiJson.put("frequencyMhz", freq)
            wifiJson.put("band", band)
            wifiJson.put("channel", channel)
        }

        val summary = "[Network Overview]\nTransport: $transport | VPN Active: $hasVpn\nIPv4: ${if (ipv4List.isEmpty()) "None" else ipv4List.joinToString()}\nIPv6: ${if (ipv6List.isEmpty()) "None" else ipv6List.joinToString()}\nGateway(s): ${if (gateways.isEmpty()) "N/A" else gateways.joinToString()}\nDNS: ${if (dnsServers.isEmpty()) "N/A" else dnsServers.joinToString()}\nInterface: ${lp?.interfaceName ?: "N/A"}\n\n$wifiSection"

        val json = JSONObject().apply {
            put("transport", transport)
            put("vpnActive", hasVpn)
            put("ipv4", JSONArray(ipv4List))
            put("ipv6", JSONArray(ipv6List))
            put("gateways", JSONArray(gateways))
            put("dns", JSONArray(dnsServers))
            put("wifi", wifiJson)
        }
        return summary to json
    }

    private fun freqToChannel(freq: Int): Int {
        return when {
            freq == 2484 -> 14
            freq in 2412..2472 -> (freq - 2407) / 5
            freq in 5170..5825 -> (freq - 5000) / 5
            freq in 5955..7115 -> (freq - 5950) / 5
            else -> -1
        }
    }

    fun fetchPublicIpInfo(): String {
        val url = URL("https://ipinfo.io/json")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 6000
            readTimeout = 6000
            requestMethod = "GET"
        }
        return try {
            val code = conn.responseCode
            if (code !in 200..299) return "Public IP lookup failed (HTTP $code)"
            val text = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
            val obj = JSONObject(text)
            "[Public IP & ASN]\nIP: ${obj.optString("ip", "N/A")}\nOrg / ASN: ${obj.optString("org", "N/A")}\nLocation: ${obj.optString("city", "")}, ${obj.optString("region", "")}, ${obj.optString("country", "")}\nTimezone: ${obj.optString("timezone", "N/A")}"
        } catch (e: Exception) {
            "Public IP error: ${e.message}"
        } finally {
            conn.disconnect()
        }
    }

    fun scanLanDevices(trustedIps: Set<String>): List<String> {
        val localIp = getLocalIpv4() ?: return listOf("No local IPv4 address found.")
        val prefix = localIp.substringBeforeLast(".")
        val results = mutableListOf<String>()

        for (i in 1..254) {
            val ip = "$prefix.$i"
            try {
                val addr = InetAddress.getByName(ip)
                if (addr.isReachable(120)) {
                    val hostName = try {
                        addr.canonicalHostName
                    } catch (_: Exception) {
                        ip
                    }
                    val statusTag = if (trustedIps.contains(ip)) "[TRUSTED]" else "[NEW]"
                    val macNote = if (ip == localIp) getLocalMac() else null
                    val vendor = lookupVendor(macNote)
                    results.add("$statusTag $ip | Host: $hostName | Vendor: $vendor")
                }
            } catch (_: Exception) {
            }
        }
        if (results.isEmpty()) {
            results.add("No reachable hosts responded on $prefix.0/24.")
        }
        return results
    }

    private fun getLocalIpv4(): String? {
        return try {
            NetworkInterface.getNetworkInterfaces()?.toList()
                ?.flatMap { it.inetAddresses.toList() }
                ?.firstOrNull { !it.isLoopbackAddress && it.hostAddress?.contains(":") == false }
                ?.hostAddress
        } catch (_: Exception) {
            null
        }
    }

    private fun getLocalMac(): String? {
        return try {
            val macBytes = NetworkInterface.getNetworkInterfaces()?.toList()
                ?.firstOrNull { it.name.equals("wlan0", ignoreCase = true) }
                ?.hardwareAddress ?: return null
            macBytes.joinToString(":") { String.format(Locale.US, "%02X", it) }
        } catch (_: Exception) {
            null
        }
    }

    fun scanPorts(host: String, portsInput: String): String {
        val ports = portsInput.split(",")
            .mapNotNull { it.trim().toIntOrNull() }
            .filter { it in 1..65535 }
            .distinct()
        if (ports.isEmpty()) return "Invalid port list. Example: 22,53,80,443"

        val openPorts = mutableListOf<Int>()
        for (port in ports) {
            try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(host, port), 350)
                    openPorts.add(port)
                }
            } catch (_: Exception) {
            }
        }
        return if (openPorts.isEmpty()) {
            "Port Scan on $host: No open TCP ports found in [${ports.joinToString()}]."
        } else {
            "Port Scan on $host: Open TCP ports -> ${openPorts.joinToString(", ")}"
        }
    }

    fun runPing(host: String, count: Int = 4): String {
        val rtts = mutableListOf<Double>()
        var received = 0
        for (i in 1..count) {
            val start = System.nanoTime()
            try {
                val reachable = InetAddress.getByName(host).isReachable(1500)
                val elapsedMs = (System.nanoTime() - start) / 1_000_000.0
                if (reachable) {
                    received++
                    rtts.add(elapsedMs)
                }
            } catch (_: Exception) {
            }
        }
        val lossPercent = ((count - received) * 100.0) / count
        return if (rtts.isEmpty()) {
            "Ping $host: $count sent, $received received, ${String.format(Locale.US, "%.1f", lossPercent)}% loss."
        } else {
            val min = rtts.minOrNull() ?: 0.0
            val max = rtts.maxOrNull() ?: 0.0
            val avg = rtts.average()
            String.format(
                Locale.US,
                "Ping %s: %d sent, %d recv, %.1f%% loss | RTT min/avg/max = %.1f / %.1f / %.1f ms",
                host, count, received, lossPercent, min, avg, max
            )
        }
    }

    fun dnsLookup(domain: String, dnsServerChoice: String): String {
        return try {
            val addresses = InetAddress.getAllByName(domain)
            val resolved = addresses.joinToString("\n") { addr ->
                val type = if (addr.hostAddress?.contains(":") == true) "AAAA/IPv6" else "A/IPv4"
                "  - [$type] ${addr.hostAddress}"
            }
            "[DNS Lookup] Target: $domain\nSelected DNS Profile: $dnsServerChoice\nResolved Records:\n$resolved"
        } catch (e: Exception) {
            "DNS Lookup failed for $domain: ${e.message}"
        }
    }

    fun simpleTraceroute(target: String): String {
        val sb = StringBuilder("Traceroute / Reachability probe for $target:\n")
        val targetAddr = try {
            InetAddress.getByName(target)
        } catch (e: Exception) {
            return "Traceroute failed: cannot resolve $target (${e.message})"
        }
        for (attempt in 1..5) {
            val t0 = System.nanoTime()
            val ok = try {
                targetAddr.isReachable(1200)
            } catch (_: Exception) {
                false
            }
            val ms = (System.nanoTime() - t0) / 1_000_000.0
            sb.append(
                String.format(
                    Locale.US,
                    "Probe #%d -> %s (%s): %s (%.1f ms)\n",
                    attempt,
                    targetAddr.hostAddress,
                    target,
                    if (ok) "Reachable" else "Timeout/Filtered",
                    ms
                )
            )
        }
        return sb.toString().trim()
    }

    fun runSpeedTest(): String {
        val testUrl = "https://speed.cloudflare.com/__down?bytes=2000000"
        val start = System.nanoTime()
        var totalBytes = 0L
        return try {
            val conn = (URL(testUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 12000
            }
            conn.inputStream.use { input ->
                val buf = ByteArray(16384)
                while (true) {
                    val read = input.read(buf)
                    if (read <= 0) break
                    totalBytes += read
                }
            }
            conn.disconnect()
            val seconds = ((System.nanoTime() - start) / 1_000_000_000.0).coerceAtLeast(0.01)
            val mbps = (totalBytes * 8.0) / (seconds * 1_000_000.0)
            String.format(
                Locale.US,
                "Download Speed: %.2f Mbps (%.2f MB in %.2f s). Upload probe requires dedicated server endpoint.",
                mbps, totalBytes / 1_000_000.0, seconds
            )
        } catch (e: Exception) {
            "Speed test error: ${e.message}"
        }
    }

    fun calculateSubnet(cidr: String): SubnetInfo? {
        val parts = cidr.trim().split("/")
        if (parts.size != 2) return null
        val ipStr = parts[0].trim()
        val prefix = parts[1].trim().toIntOrNull() ?: return null
        if (prefix !in 0..32) return null

        val octets = ipStr.split(".").mapNotNull { it.toIntOrNull() }
        if (octets.size != 4 || octets.any { it !in 0..255 }) return null

        val ipInt = ((octets[0] and 0xFF) shl 24) or
                ((octets[1] and 0xFF) shl 16) or
                ((octets[2] and 0xFF) shl 8) or
                (octets[3] and 0xFF)

        val maskInt = if (prefix == 0) 0 else (-1 shl (32 - prefix))
        val netInt = ipInt and maskInt
        val bcastInt = netInt or maskInt.inv()

        val totalAddresses = 1L shl (32 - prefix)
        val usableHosts = when {
            prefix >= 31 -> 0L
            else -> (totalAddresses - 2).coerceAtLeast(0L)
        }

        val firstHostInt = if (usableHosts > 0) netInt + 1 else netInt
        val lastHostInt = if (usableHosts > 0) bcastInt - 1 else bcastInt

        return SubnetInfo(
            cidr = "$ipStr/$prefix",
            networkAddress = intToIpv4(netInt),
            broadcastAddress = intToIpv4(bcastInt),
            subnetMask = intToIpv4(maskInt),
            firstHost = intToIpv4(firstHostInt),
            lastHost = intToIpv4(lastHostInt),
            usableHosts = usableHosts
        )
    }

    private fun intToIpv4(value: Int): String {
        return listOf(
            (value ushr 24) and 0xFF,
            (value ushr 16) and 0xFF,
            (value ushr 8) and 0xFF,
            value and 0xFF
        ).joinToString(".")
    }

    fun sendWakeOnLan(macAddress: String, broadcastIp: String = "255.255.255.255", port: Int = 9): String {
        val hex = macAddress.replace(":", "").replace("-", "").trim()
        if (hex.length != 12 || !hex.matches(Regex("[0-9A-Fa-f]{12}"))) {
            return "Invalid MAC address format. Use AA:BB:CC:DD:EE:FF"
        }
        val macBytes = ByteArray(6) { idx ->
            hex.substring(idx * 2, idx * 2 + 2).toInt(16).toByte()
        }
        val magicPacket = ByteArray(6 + 16 * 6)
        for (i in 0 until 6) magicPacket[i] = 0xFF.toByte()
        for (i in 0 until 16) {
            System.arraycopy(macBytes, 0, magicPacket, 6 + i * 6, 6)
        }

        return try {
            DatagramSocket().use { socket ->
                socket.broadcast = true
                val address = InetAddress.getByName(broadcastIp)
                val packet = DatagramPacket(magicPacket, magicPacket.size, address, port)
                socket.send(packet)
            }
            "Magic Packet sent to $macAddress via $broadcastIp:$port"
        } catch (e: Exception) {
            "Wake-on-LAN failed: ${e.message}"
        }
    }
}

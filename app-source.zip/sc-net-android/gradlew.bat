@rem SC NET Gradle launcher helper
@echo off
where gradle >nul 2>nul
if %errorlevel% equ 0 (
  gradle %*
  exit /b %errorlevel%
)
echo Gradle CLI not found in PATH. Please run inside Android Studio or GitHub Actions.
exit /b 1

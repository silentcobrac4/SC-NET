# Default ProGuard rules for SC NET
